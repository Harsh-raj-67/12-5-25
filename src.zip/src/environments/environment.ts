export const environment = {
    apiUrl:"http://localhost:3000"
};
